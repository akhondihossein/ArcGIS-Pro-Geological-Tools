Geological Section Profile — Tamper-Evident 2026

Developer: Engineer Hossein Akhondi
Email: hossein.akhondi1988@gmail.com
Year: 2026

This package follows the Tamper-Evident distribution structure used for the Feature Rose Analysis package. It contains the Python toolbox, ArcGIS metadata XML files, a compiled integrity backend, a SHA-256 integrity manifest, a digitally generated RSA-PSS-SHA256 signature, and the corresponding public key.

The private signing key is intentionally NOT included in this package.

Any modification to the signed metadata manifest, metadata XML files, or compiled backend changes the recorded hashes and invalidates the integrity state. Keep all files in this folder together when installing the toolbox in ArcGIS Pro.

The protected attribution is: Designed and developed in 2026 by Engineer Hossein Akhondi. Email: hossein.akhondi1988@gmail.com.
